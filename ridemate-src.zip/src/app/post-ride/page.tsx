'use client'
import { useState, useRef, useEffect } from 'react'
import { BottomNav } from '@/components/layout/BottomNav'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { CITIES, toKurdishNum } from '@/lib/utils'
import { T } from '@/lib/theme'
import { RideCard } from '@/components/ui/RideCard'
import SketchCar from '@/components/ui/icons/SketchCar'
import Card from '@/components/ui/Card'
import DashedDivider from '@/components/ui/DashedDivider'

const CITY_KEYS = ['', 'erbil', 'suli', 'duhok'] as const

export default function PostRidePage() {
  const router = useRouter()
  const supabase = createClient()
  const [checking, setChecking] = useState(true)
  const [isVerifiedDriver, setIsVerifiedDriver] = useState(false)
  const [activeTab, setActiveTab] = useState<'post' | 'manage'>('post')

  // Become-a-driver state
  const [licenseFile, setLicenseFile] = useState<File | null>(null)
  const [selfieFile, setSelfieFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [uploadError, setUploadError] = useState('')
  const [submitted, setSubmitted] = useState(false)
  const licenseRef = useRef<HTMLInputElement>(null)
  const selfieRef = useRef<HTMLInputElement>(null)

  // Post ride form state
  const [fromCity, setFromCity] = useState('')
  const [toCity, setToCity] = useState('')
  const [date, setDate] = useState('')
  const [time, setTime] = useState('')
  const [seats, setSeats] = useState('1')
  const [seatsTapped, setSeatsTapped] = useState(false)
  const [priceType, setPriceType] = useState<'coffee' | 'iqd'>('coffee')
  const [price, setPrice] = useState('')
  const [carMake, setCarMake] = useState('')
  const [carModel, setCarModel] = useState('')
  const [carColor, setCarColor] = useState('')
  const [notes, setNotes] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [editingRideId, setEditingRideId] = useState<string | null>(null)
  const dateRef = useRef<HTMLInputElement>(null)
  const timeRef = useRef<HTMLInputElement>(null)

  // Manage tab state
  const [myPostedRides, setMyPostedRides] = useState<any[]>([])
  const [loadingManage, setLoadingManage] = useState(false)

  useEffect(() => {
    if (new URLSearchParams(window.location.search).get('tab') === 'manage') setActiveTab('manage')
  }, [])

  useEffect(() => { checkVerification() }, [])

  async function checkVerification() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { setChecking(false); return }
    const { data: profile } = await supabase.from('profiles').select('role, verification_status').eq('id', user.id).single()
    if (profile && (profile.role === 'driver' || profile.role === 'both') && profile.verification_status === 'verified') {
      setIsVerifiedDriver(true)
    }
    setChecking(false)
  }

  async function loadPostedRides() {
    setLoadingManage(true)
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { setLoadingManage(false); return }
    const { data: rides } = await supabase
      .from('rides')
      .select('id, from_city, to_city, departure_time, available_seats, price_type, price_iqd, status, car_make, car_model, car_color, notes')
      .eq('driver_id', user.id)
      .order('created_at', { ascending: false })
    if (rides) {
      setMyPostedRides(rides)
    } else {
      setMyPostedRides([])
    }
    setLoadingManage(false)
  }

  useEffect(() => {
    if (activeTab === 'manage' && isVerifiedDriver) loadPostedRides()
  }, [activeTab, isVerifiedDriver])

  // ─── Become a Driver: submit ───
  async function handleVerifySubmit() {
    setUploadError('')
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { setUploadError('تکایە سەرەتا چوونەژوورەوە بکە'); return }
    if (!licenseFile || !selfieFile) { setUploadError('تکایە مۆڵەتنامە و سێلفی بنێرە'); return }
    setUploading(true)
    const licExt = licenseFile.name.split('.').pop()
    const { error: licErr } = await supabase.storage.from('documents').upload(`${user.id}/license.${licExt}`, licenseFile, { upsert: true })
    if (licErr) { setUploadError(licErr.message); setUploading(false); return }
    const selfieExt = selfieFile.name.split('.').pop()
    const { error: selfieErr } = await supabase.storage.from('documents').upload(`${user.id}/selfie.${selfieExt}`, selfieFile, { upsert: true })
    if (selfieErr) { setUploadError(selfieErr.message); setUploading(false); return }
    await supabase.from('profiles').update({ role: 'both', verification_status: 'pending' }).eq('id', user.id)
    setUploading(false)
    setSubmitted(true)
  }

  function startEdit(ride: any) {
    const dep = new Date(ride.departure_time)
    setEditingRideId(ride.id)
    setFromCity(ride.from_city)
    setToCity(ride.to_city)
    setDate(dep.toISOString().split('T')[0])
    setTime(dep.toTimeString().slice(0, 5))
    setSeats(String(ride.available_seats))
    setSeatsTapped(true)
    setPriceType(ride.price_type === 'coffee' ? 'coffee' : 'iqd')
    setPrice(ride.price_iqd ? String(ride.price_iqd) : '')
    setCarMake(ride.car_make || '')
    setCarModel(ride.car_model || '')
    setCarColor(ride.car_color || '')
    setNotes(ride.notes || '')
    setActiveTab('post')
  }

  // ─── Post Ride: helpers ───
  function cycleCity(current: string, setter: (v: string) => void) {
    const idx = CITY_KEYS.indexOf(current as typeof CITY_KEYS[number])
    const next = CITY_KEYS[(idx + 1) % CITY_KEYS.length]
    setter(next)
  }
  function cycleSeats() {
    if (!seatsTapped) { setSeatsTapped(true); setSeats('1'); return }
    const n = parseInt(seats)
    setSeats(String(n >= 4 ? 1 : n + 1))
  }
  function formatDate(d: string) {
    if (!d) return 'بەروار'
    const [, m, day] = d.split('-')
    return `${toKurdishNum(parseInt(day))}/${toKurdishNum(parseInt(m))}`
  }

  async function handleSubmit() {
    if (!fromCity) { setError('تکایە شاری دەستپێکردن دیاری بکە'); return }
    if (!toCity) { setError('تکایە شاری مەبەست دیاری بکە'); return }
    if (!date) { setError('تکایە بەرواری گەشت دیاری بکە'); return }
    if (!time) { setError('تکایە کاتی گەشت دیاری بکە'); return }
    if (!carMake) { setError('تکایە جۆری ئۆتۆمبێل دیاری بکە'); return }
    if (!carModel) { setError('تکایە مۆدێلی ئۆتۆمبێل دیاری بکە'); return }
    if (!carColor) { setError('تکایە ڕەنگی ئۆتۆمبێل دیاری بکە'); return }
    if (fromCity === toCity) {
      setError('شوێنی چوون و هاتن ناتوانن هاوشێوە بن'); return
    }
    setLoading(true); setError('')
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { router.push('/'); return }
    const departureTime = new Date(`${date}T${time}:00`).toISOString()
    const rideData = {
      from_city: fromCity, to_city: toCity,
      departure_time: departureTime, available_seats: parseInt(seats),
      price_type: priceType === 'coffee' ? 'coffee' : 'iqd',
      price_iqd: priceType === 'iqd' ? parseInt(price) || 0 : null,
      car_make: carMake || null, car_model: carModel || null,
      car_color: carColor || null, notes: notes || null,
    }
    const { error: saveError } = editingRideId
      ? await supabase.from('rides').update(rideData).eq('id', editingRideId)
      : await supabase.from('rides').insert({ ...rideData, driver_id: user.id, status: 'active' })
    if (saveError) { setError(saveError.message); setLoading(false) }
    else {
      // If editing, notify approved passengers about changes
      if (editingRideId) {
        const { data: approved } = await supabase.from('ride_requests').select('passenger_id').eq('ride_id', editingRideId).eq('status', 'approved')
        if (approved && approved.length > 0) {
          const notifs = approved.map((r: any) => ({
            user_id: r.passenger_id,
            type: 'ride_updated',
            ride_id: editingRideId,
            from_user_id: user.id,
            metadata: { changes: ['وردەکاری گەشتەکە گۆڕدرا'] },
          }))
          await supabase.from('notifications').insert(notifs)
        }
      }
      setEditingRideId(null); setActiveTab('manage'); loadPostedRides(); setFromCity(''); setToCity(''); setDate(''); setTime(''); setSeats('1'); setPrice(''); setCarMake(''); setCarModel(''); setCarColor(''); setNotes(''); setLoading(false)
    }
  }

  // ─── Loading ───
  if (checking) return (
    <div style={{ direction: 'rtl', minHeight: '100vh', background: T.bg, maxWidth: 480, margin: '0 auto' }}>
      <BottomNav />
    </div>
  )

  // ═══════════════════════════════════════
  // BECOME A DRIVER (unverified)
  // ═══════════════════════════════════════
  if (!isVerifiedDriver) {
    if (submitted) return (
      <div style={{
        direction: 'rtl', minHeight: '100vh', background: T.bg,
        maxWidth: 480, margin: '0 auto', display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', padding: '24px 20px',
      }}>
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke={T.green} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" style={{ marginBottom: 20 }}>
          <circle cx="12" cy="12" r="10" /><polyline points="8 12 11 15 16 9" />
        </svg>
        <h2 style={{ fontSize: 20, fontWeight: 700, color: T.text, marginBottom: 8 }}>ناسنامەکانت نێردران</h2>
        <p style={{ fontSize: 13, color: T.textDim, textAlign: 'center', marginBottom: 32, lineHeight: 1.8 }}>
          کاتێک پشتڕاست کرایتەوە، دەتوانیت گەشت پۆست بکەیت
        </p>
        <div onClick={() => router.push('/home')} style={{
          background: T.card, border: `1px solid ${T.border}`, borderRadius: 12,
          padding: '12px 24px', fontSize: 13, color: T.textMid, cursor: 'pointer',
        }}>گەڕانەوە بۆ سەرەکی</div>
        <BottomNav />
      </div>
    )

    return (
      <div style={{
        direction: 'rtl', height: '100vh', background: T.bg,
        maxWidth: 480, margin: '0 auto', display: 'flex', flexDirection: 'column',
      }}>
        <div style={{ padding: '24px 20px 0', flexShrink: 0 }}>
          <span onClick={() => router.push('/home')} style={{ color: T.textFaint, fontSize: 13, cursor: 'pointer' }}>← گەڕانەوە</span>
        </div>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '0 20px' }}>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: T.text, marginBottom: 10, lineHeight: 1.6 }}>
            بۆ بوون بە <span style={{ color: T.orange }}>شۆفێر</span>، پێویستە خۆت ڤێریفای بکەی
          </h1>
          <p style={{ color: T.textDim, marginBottom: 28, fontSize: 12, lineHeight: 1.8 }}>
            مۆڵەتی شۆفێری و سێلفی بنێرە بۆ ئەوەی ببی بە شۆفێڕ
          </p>
          {uploadError && <p style={{ color: T.red, fontSize: 12, marginBottom: 12 }}>{uploadError}</p>}

          <input type="file" accept="image/*" ref={licenseRef} style={{ display: 'none' }} onChange={e => setLicenseFile(e.target.files?.[0] || null)} />
          <div onClick={() => licenseRef.current?.click()} style={{
            background: T.card, border: `1px solid ${licenseFile ? 'rgba(74,222,128,0.15)' : T.border}`,
            borderRadius: 16, padding: 20, marginBottom: 10, cursor: 'pointer',
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
              <span style={{ fontSize: 9, color: T.textFaint, letterSpacing: 1 }}>مۆڵەتی شۆفێری</span>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ fontSize: 9, color: T.textFaint, letterSpacing: 1.5 }}>کوردستان</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={T.textFaint} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><path d="M2 12h20" /><path d="M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20" /></svg>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
              <div style={{ width: 56, height: 68, borderRadius: 8, background: licenseFile ? 'rgba(74,222,128,0.08)' : T.cardInner, border: `1px solid ${licenseFile ? 'rgba(74,222,128,0.2)' : T.divider}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {licenseFile ? <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={T.green} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="8 12 11 15 16 9" /></svg> : <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={T.iconDim} strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="8" r="4" /><path d="M20 21c0-3.31-3.58-6-8-6s-8 2.69-8 6" /></svg>}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ height: 6, background: T.cardInner, borderRadius: 3, width: '80%', marginBottom: 8 }} />
                <div style={{ height: 6, background: T.cardInner, borderRadius: 3, width: '60%', marginBottom: 8 }} />
                <div style={{ height: 6, background: T.cardInner, borderRadius: 3, width: '45%' }} />
              </div>
            </div>
            <div style={{ borderTop: `1px solid ${T.border}`, marginTop: 16, paddingTop: 12, textAlign: 'center' }}>
              <span style={{ fontSize: 12, color: licenseFile ? T.green : T.textDim, fontWeight: 500 }}>
                {licenseFile ? 'ناردنمان! چاوەڕێی وەڵامبە' : 'وێنەی مۆڵەتنامەکەت ئەپلۆد بکە'}
              </span>
            </div>
          </div>

          <input type="file" accept="image/*" capture="user" ref={selfieRef} style={{ display: 'none' }} onChange={e => setSelfieFile(e.target.files?.[0] || null)} />
          <div onClick={() => selfieRef.current?.click()} style={{
            background: T.card, border: `1px solid ${selfieFile ? 'rgba(74,222,128,0.15)' : T.border}`,
            borderRadius: 16, padding: 20, marginBottom: 10, cursor: 'pointer',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
              <div style={{ width: 56, height: 56, borderRadius: '50%', background: selfieFile ? 'rgba(74,222,128,0.08)' : T.cardInner, border: `2px dashed ${selfieFile ? 'rgba(74,222,128,0.3)' : T.divider}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                {selfieFile ? <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={T.green} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="8 12 11 15 16 9" /></svg> : <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={T.iconDim} strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" /><circle cx="12" cy="13" r="4" /></svg>}
              </div>
              <div>
                <div style={{ fontWeight: 600, color: selfieFile ? T.green : T.textMid, fontSize: 13, marginBottom: 4 }}>{selfieFile ? 'سێلفییەکەت سەرکەوتوو بوو' : 'سێلفی بگرە'}</div>
                <div style={{ fontSize: 11, color: T.textFaint }}>وێنەیەکی ڕوونی ڕووخسارت</div>
              </div>
            </div>
          </div>
        </div>
        <div style={{ flexShrink: 0, padding: '0 20px 96px' }}>
          <button onClick={handleVerifySubmit} disabled={uploading} style={{
            background: T.card, color: T.orange, border: `1px solid ${T.border}`,
            borderRadius: 16, padding: 16, fontSize: 14, fontWeight: 600,
            cursor: uploading ? 'default' : 'pointer', width: '100%',
            opacity: uploading ? 0.5 : 1, fontFamily: "'Noto Sans Arabic', sans-serif",
          }}>{uploading ? '...چاوەڕوان بە' : 'بنێرە'}</button>
        </div>
        <BottomNav />
      </div>
    )
  }

  // ═══════════════════════════════════════
  // VERIFIED DRIVER — POST + MANAGE
  // ═══════════════════════════════════════
  return (
    <div style={{ direction: 'rtl', minHeight: '100vh', background: T.bg, maxWidth: 480, margin: '0 auto', padding: '24px 20px 96px', position: 'relative' }}>

      <div style={{ marginBottom: 20 }}>
        <h1 style={{ fontSize: 20, fontWeight: 700, color: T.text }}><span style={{ color: T.orange }}>ڕێ</span> گەشت پۆستکە</h1>
      </div>

      {/* Tab switcher */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
        <div onClick={() => setActiveTab('post')} style={{
          flex: 1, padding: '9px 0', textAlign: 'center', borderRadius: 9,
          fontSize: 12, fontWeight: 600, cursor: 'pointer',
          background: activeTab === 'post' ? T.accent : T.card,
          color: activeTab === 'post' ? T.onAccent : T.text,
          border: `2px solid ${T.text}`,
          boxShadow: activeTab === 'post' ? `3px 3px 0 ${T.text}` : `2px 2px 0 ${T.textDim}`,
        }}>گەشتێکی نوێ</div>
        <div onClick={() => setActiveTab('manage')} style={{
          flex: 1, padding: '9px 0', textAlign: 'center', borderRadius: 9,
          fontSize: 12, fontWeight: 600, cursor: 'pointer',
          background: activeTab === 'manage' ? T.accent : T.card,
          color: activeTab === 'manage' ? T.onAccent : T.text,
          border: `2px solid ${T.text}`,
          boxShadow: activeTab === 'manage' ? `3px 3px 0 ${T.text}` : `2px 2px 0 ${T.textDim}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
        }}>
          گەشتەکانم
        </div>
      </div>

      {/* ═══ POST TAB ═══ */}
      {activeTab === 'post' && (
        <div style={{ paddingBottom: 100 }}>
          {/* SketchCar */}
          <div style={{ display: 'flex', justifyContent: 'center', padding: '0 0 14px' }}>
            <SketchCar size={110} color={T.accent} />
          </div>

          {/* Route card */}
          <Card style={{ marginBottom: 14, overflow: 'hidden' }}>
            <div style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, flexShrink: 0 }}>
                <div style={{ width: 8, height: 8, borderRadius: '50%', border: `2px solid ${T.text}` }} />
                <div style={{ width: 1, height: 24, background: T.divider }} />
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: T.text }} />
              </div>
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 0 }}>
                <div onClick={() => cycleCity(fromCity, setFromCity)} style={{ background: T.cardInner, borderRadius: 10, padding: '10px 14px', fontSize: 13, color: fromCity ? T.text : T.textDim, cursor: 'pointer' }}>
                  {fromCity ? CITIES[fromCity] : 'لە کوێ؟'}
                </div>
                <DashedDivider style={{ margin: '0 4px' }} />
                <div onClick={() => cycleCity(toCity, setToCity)} style={{ background: T.cardInner, borderRadius: 10, padding: '10px 14px', fontSize: 13, color: toCity ? T.text : T.textDim, cursor: 'pointer' }}>
                  {toCity ? CITIES[toCity] : 'بۆ کوێ؟'}
                </div>
              </div>
            </div>
          </Card>

          {/* Date/Time/Seats card */}
          <Card style={{ marginBottom: 14, overflow: 'hidden' }}>
            <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center' }}>
              <div onClick={() => dateRef.current?.showPicker()} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', cursor: 'pointer', position: 'relative' }}>
                <div style={{ fontSize: 9, color: T.textMid, marginBottom: 3 }}>بەروار</div>
                <div style={{ fontSize: 13, color: date ? T.text : T.textDim, fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {date ? formatDate(date) : (
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={T.iconDim} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" /><line x1="16" y1="2" x2="16" y2="6" /><line x1="8" y1="2" x2="8" y2="6" /><line x1="3" y1="10" x2="21" y2="10" /></svg>
                  )}
                </div>
                <input ref={dateRef} type="date" value={date} onChange={e => setDate(e.target.value)} style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', opacity: 0 }} />
              </div>
              <div style={{ width: 0, height: 28, borderRight: `1.5px dashed ${T.textDim}` }} />
              <div onClick={() => timeRef.current?.showPicker()} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', cursor: 'pointer', position: 'relative' }}>
                <div style={{ fontSize: 9, color: T.textMid, marginBottom: 3 }}>کات</div>
                <div style={{ fontSize: 13, color: time ? T.text : T.textDim, fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {time ? time : (
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={T.iconDim} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" /></svg>
                  )}
                </div>
                <input ref={timeRef} type="time" value={time} onChange={e => setTime(e.target.value)} style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', opacity: 0 }} />
              </div>
              <div style={{ width: 0, height: 28, borderRight: `1.5px dashed ${T.textDim}` }} />
              <div onClick={cycleSeats} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', cursor: 'pointer' }}>
                <div style={{ fontSize: 9, color: T.textMid, marginBottom: 3 }}>جێگا</div>
                <div style={{ fontSize: 13, color: T.text, fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={seatsTapped ? T.text : T.iconDim} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M6 19v2" /><path d="M18 19v2" />
                    <path d="M7 19h10a2 2 0 0 0 2-2v-3a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v3a2 2 0 0 0 2 2z" />
                    <path d="M7 10V7a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v3" />
                    <path d="M9 14h6" />
                  </svg>
                  {seatsTapped && <span style={{ fontSize: 10, fontWeight: 700, color: T.text, marginRight: 4 }}>{seats}</span>}
                </div>
              </div>
            </div>
          </Card>

          {/* Price card */}
          <Card style={{ marginBottom: 14, overflow: 'hidden', padding: '12px 16px' }}>
            <div style={{ fontSize: 9, color: T.textFaint, marginBottom: 0, fontWeight: 600 }}>نرخ</div>
            <DashedDivider style={{ margin: '6px 0' }} />
            <div style={{ display: 'flex', gap: 8 }}>
              <div onClick={() => setPriceType('coffee')} style={{
                flex: 1, padding: '10px 0', textAlign: 'center', borderRadius: 9, cursor: 'pointer',
                background: priceType === 'coffee' ? T.accent : T.card,
                border: `2px solid ${T.text}`,
                boxShadow: priceType === 'coffee' ? `3px 3px 0 ${T.text}` : `2px 2px 0 ${T.textDim}`,
                color: priceType === 'coffee' ? T.onAccent : T.text, fontSize: 12, fontWeight: 500,
              }}>قاوەیەک</div>
              <div onClick={() => setPriceType('iqd')} style={{
                flex: 1, padding: '10px 0', textAlign: 'center', borderRadius: 9, cursor: 'pointer',
                background: priceType === 'iqd' ? T.accent : T.card,
                border: `2px solid ${T.text}`,
                boxShadow: priceType === 'iqd' ? `3px 3px 0 ${T.text}` : `2px 2px 0 ${T.textDim}`,
                color: priceType === 'iqd' ? T.onAccent : T.text, fontSize: 12, fontWeight: 500,
              }}>پارە</div>
            </div>
            {priceType === 'iqd' && (
              <div style={{ marginTop: 10 }}>
                <input className="money-input" type="text" value={price} onChange={e => { const raw = e.target.value.replace(/[^0-9]/g, ''); const v = Number(raw); if (!raw || (v >= 0 && v <= 5000)) setPrice(raw) }} inputMode="numeric" pattern="[0-9]*" placeholder="0"
                  style={{ background: T.cardInner, border: `1.5px solid ${T.textDim}`, borderRadius: 8, padding: '10px 12px', width: '100%', fontSize: 12, color: T.text, WebkitTextFillColor: T.text, outline: 'none', direction: 'ltr', textAlign: 'left', fontFamily: "'Noto Sans Arabic', sans-serif" }} />
              </div>
            )}
          </Card>

          {/* Car + Notes card */}
          <Card style={{ marginBottom: 14, overflow: 'hidden', padding: '12px 16px' }}>
            <div style={{ fontSize: 9, color: T.textFaint, marginBottom: 0, fontWeight: 600 }}>زانیاری ئۆتۆمبێل</div>
            <DashedDivider style={{ margin: '6px 0' }} />
            <div style={{ display: 'flex', gap: 8, marginBottom: 0 }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 9, color: T.textDim, marginBottom: 4 }}>جۆر</div>
                <input value={carMake} onChange={e => setCarMake(e.target.value)} placeholder="Toyota" className="car-input" style={{ background: T.cardInner, border: `1.5px solid ${T.textDim}`, borderRadius: 8, padding: '10px 12px', width: '100%', fontSize: 12, color: T.text, WebkitTextFillColor: T.text, outline: 'none', fontFamily: "'Noto Sans Arabic', sans-serif" }} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 9, color: T.textDim, marginBottom: 4 }}>مۆدێل</div>
                <input value={carModel} onChange={e => setCarModel(e.target.value)} placeholder="Camry" className="car-input" style={{ background: T.cardInner, border: `1.5px solid ${T.textDim}`, borderRadius: 8, padding: '10px 12px', width: '100%', fontSize: 12, color: T.text, WebkitTextFillColor: T.text, outline: 'none', fontFamily: "'Noto Sans Arabic', sans-serif" }} />
              </div>
            </div>
            <DashedDivider style={{ margin: '10px 4px' }} />
            <div style={{ marginBottom: 0 }}>
              <div style={{ fontSize: 9, color: T.textDim, marginBottom: 4 }}>ڕەنگ</div>
              <input value={carColor} onChange={e => setCarColor(e.target.value)} placeholder="White" className="car-input" style={{ background: T.cardInner, border: `1.5px solid ${T.textDim}`, borderRadius: 8, padding: '10px 12px', width: '100%', fontSize: 12, color: T.text, WebkitTextFillColor: T.text, outline: 'none', fontFamily: "'Noto Sans Arabic', sans-serif" }} />
            </div>
            <DashedDivider style={{ margin: '10px 4px' }} />
            <div style={{ fontSize: 9, color: T.textFaint, marginBottom: 0, fontWeight: 600 }}>تێبینی</div>
            <DashedDivider style={{ margin: '6px 0' }} />
            <textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="هەر شتێک دەربارەی گەشتەکەت..." rows={2} className="note-input" style={{ background: T.cardInner, border: `1.5px solid ${T.textDim}`, borderRadius: 8, padding: '10px 12px', width: '100%', fontSize: 12, color: T.text, WebkitTextFillColor: T.text, outline: 'none', resize: 'none', fontFamily: "'Noto Sans Arabic', sans-serif", lineHeight: 1.8 }} />
          </Card>

          {error && <p style={{ color: T.red, fontSize: 12, textAlign: 'center', marginBottom: 12 }}>{error}</p>}

          <div onClick={handleSubmit} style={{
            background: T.accent, color: T.onAccent, border: `2px solid ${T.text}`, borderRadius: 12,
            padding: '14px 0', textAlign: 'center', cursor: loading ? 'default' : 'pointer',
            opacity: loading ? 0.5 : 1, width: '100%',
            boxShadow: `3px 3px 0 ${T.text}`,
          }}>
            <span style={{ fontSize: 15, fontWeight: 800 }}>{loading ? '...' : editingRideId ? 'نوێکردنەوە' : 'بینێرە!'}</span>
          </div>
        </div>
      )}

      {/* ═══ MANAGE TAB ═══ */}
      {activeTab === 'manage' && (
        <div>
          {loadingManage ? <div /> : myPostedRides.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '4rem 0' }}>
              <p style={{ color: T.textFaint, fontSize: 14 }}>هێشتا گەشتت پۆست نەکردووە</p>
            </div>
          ) : myPostedRides.map(ride => {
            const isCompleted = ride.status === 'completed'
            const isCancelled = ride.status === 'cancelled'
            const isDimmed = isCompleted || isCancelled

            const rideStatusConfig: Record<string, { text: string; color: string; bg: string }> = {
              active: { text: 'چالاک', color: T.amber, bg: 'rgba(251,191,36,0.1)' },
              full: { text: '٠ جێ', color: T.text, bg: T.chipBg },
              completed: { text: 'تەواو بوو', color: T.green, bg: 'rgba(74,222,128,0.1)' },
              cancelled: { text: 'هەڵوەشێنرایەوە', color: T.red, bg: 'rgba(248,113,113,0.1)' },
            }
            const st = rideStatusConfig[ride.status] || rideStatusConfig.active

            return (
              <RideCard
                key={ride.id}
                ride={ride}
                status={st}
                dimmed={isDimmed}
                editButton={!isCompleted && !isCancelled ? (
                  <span
                    onClick={() => startEdit(ride)}
                    style={{ fontSize: 12, color: T.textDim, cursor: 'pointer' }}
                  >دەسکاری</span>
                ) : undefined}
              />
            )
          })}
        </div>
      )}

      <BottomNav />
    </div>
  )
}
